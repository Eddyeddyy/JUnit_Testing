package Task;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TaskServiceTest {

	@Test
	public void testTaskServiceAddTask() {
		TaskService task = new TaskService();
		TaskService task1 = new TaskService();
		TaskClass tas = new TaskClass("01221", "Task 1", "Test task");
		task.addTask(tas);
		task1.addTask(tas);
		assertTrue(task.getTask0().equals(task1.getTask0()));
	}
	
	@Test
	public void testTaskServiceRemove() {
		TaskService task = new TaskService();
		TaskService task1 = new TaskService();
		TaskClass tas = new TaskClass("01221", "Task 1", "Test task");
		TaskClass tas1 = new TaskClass("01222", "Task 2", "Test task");
		task.addTask(tas);
		task1.addTask(tas);
		task1.addTask(tas1);
		task1.removeTask(tas.getID());
		assertFalse(task.getTask0().equals(task1.getTask0()));
	}

	@Test
	public void testtaskServiceUpdateTaskName() {
		TaskService task = new TaskService();
		TaskClass tas = new TaskClass("01221", "Task 1", "Test task");
		task.addTask(tas);
		task.updateTask("01221", "Task 2", "Test task");
		assertTrue(tas.getName().equals("Task 2"));
	}
	
	@Test
	public void testtaskServiceUpdateTaskDescription() {
		TaskService task = new TaskService();
		TaskClass tas = new TaskClass("01221", "Task 1", "Test task");
		task.addTask(tas);
		task.updateTask("01221", "Task 2", "Real Task");
		assertTrue(tas.getDescription().equals("Real Task"));
	}
	
}
