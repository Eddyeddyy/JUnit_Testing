package Task;

import java.util.ArrayList;

public class TaskService {
	
	private ArrayList<TaskClass> tasks;
	
	public TaskService() {
		tasks = new ArrayList<>();
	}
	
	public void addTask(TaskClass task) {
		for (TaskClass t : tasks) {
			if (t.getID().equals(t.getID())){
				break;
			}
		}
		tasks.add(task);
	}
	
	public void removeTask(String ID) {
		for (TaskClass t : tasks) {
			if (t.getID().equals(ID)) {
				tasks.remove(t);
			}
		}
	}
	
	public void updateTask(String ID, String name, String desc) {
		for (TaskClass t : tasks) {
			if (t.getID().equals(ID)) {
				t.setName(name);
				t.setDescription(desc);
			}
		}
	}
	
	public String getTask0() {
		return tasks.get(0).getID();
	}

}
