package Task;


import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;


public class TaskTest {
	
	@Test
	public void testTask() {
		TaskClass task = new TaskClass("01221", "Task 1", "Test task");
		assertTrue(task.getID().equals("01221"));
		assertTrue(task.getName().equals("Task 1"));
		assertTrue(task.getDescription().equals("Test task"));
	}
	
	@Test
	public void testTaskIDTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new TaskClass("1234567891011", "Task 1", "Test task");
		});
	}
	
	@Test
	public void testTaskIDNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new TaskClass(null, "Task 1", "Test task");
		});
	}
	
	@Test
	public void testTaskNameTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new TaskClass("01221", "Task 1123456789123456789", "Test task");
		});
	}
	@Test
	public void testTaskNameNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new TaskClass("01221", null, "Test task");
		});
	}
	
	@Test
	public void testTaskDescriptionTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new TaskClass("01221", "Task 1", "Test task that may be a little bit too long fhdjskafhdjskalfhdjskal");
		});
	}
	
	@Test
	public void testTaskDescriptionNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new TaskClass("01221", "Task 1", null);
		});
	}

}

