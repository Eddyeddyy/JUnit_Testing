package Task;


public class TaskClass {
	
	private String taskID;
	private String taskName;
	private String taskDescription;
	
	public TaskClass(String ID, String name, String desc){
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (desc == null || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.taskID = ID;
		this.taskName = name;
		this.taskDescription = desc;
	}
	
	public void setID(String ID) {
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.taskID = ID;
	}
	
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.taskName = name;
	}
	
	public void setDescription(String desc) {
		if (desc == null || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.taskDescription = desc;
	}
	
	public String getID() {
		return taskID;
	}
	
	public String getName() {
		return taskName;
	}
	
	public String getDescription() {
		return taskDescription;
	}
	
	

}
