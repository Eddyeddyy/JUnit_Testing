package Contact;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


import org.junit.Test;


public class ContactServiceTest {
	
	@Test
	public void testContactServiceAddContact() {
		ContactService contact = new ContactService();
		ContactService contact1 = new ContactService();
		Contact con = new Contact("123456" , "Joe", "Donald", "4879568759", "1234 Fake St");
		contact.addContact(con);
		contact1.addContact(con);
		assertTrue(contact.getContact0().equals(contact1.getContact0()));
	}
	
	@Test
	public void testContactServiceRemove() {
		ContactService contact = new ContactService();
		ContactService contact1 = new ContactService();
		Contact con = new Contact("123456" , "Joe", "Donald", "4879568759", "1234 Fake St");
		Contact con1 = new Contact("1234568" , "Joe", "Donald", "4879568759", "1234 Fake St");
		contact.addContact(con);
		contact1.addContact(con);
		contact1.addContact(con1);
		contact1.removeContact(con.getContactID());
		assertFalse(contact.getContact0().equals(contact1.getContact0()));
	}

	@Test
	public void testContactServiceUpdateFirstName() {
		ContactService contact = new ContactService();
		Contact con = new Contact("123456" , "Joe", "Donald", "4879568759", "1234 Fake St");
		contact.addContact(con);
		contact.updateContact("123456" , "Rick", "Donald", "4879568759", "1234 Fake St");
		assertTrue(con.getFirstName().equals("Rick"));
	}
	
	@Test
	public void testContactServiceUpdateLastName() {
		ContactService contact = new ContactService();
		Contact con = new Contact("123456" , "Joe", "Donald", "4879568759", "1234 Fake St");
		contact.addContact(con);
		contact.updateContact("123456" , "Joe", "Rick", "4879568759", "1234 Fake St");
		assertTrue(con.getLastName().equals("Rick"));
	}
	
	@Test
	public void testContactServiceUpdatePhone() {
		ContactService contact = new ContactService();
		Contact con = new Contact("123456" , "Joe", "Donald", "4879568759", "1234 Fake St");
		contact.addContact(con);
		contact.updateContact("123456" , "Joe", "Donald", "5689574123", "1234 Fake St");
		assertTrue(con.getPhoneNumber().equals("5689574123"));
	}
	
	@Test
	public void testContactServiceUpdateAddress() {
		ContactService contact = new ContactService();
		Contact con = new Contact("123456" , "Joe", "Donald", "4879568759", "1234 Fake St");
		contact.addContact(con);
		contact.updateContact("123456" , "Joe", "Donald", "5689574123", "1234 NotReal Ave");
		assertTrue(con.getAddress().equals("1234 NotReal Ave"));
	}
	
	
}
