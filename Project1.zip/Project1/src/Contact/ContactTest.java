package Contact;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;


public class ContactTest {

	@Test
	public void testContact() {
		Contact con = new Contact("123456" , "Joe", "Donald", "4879568759", "1234 Fake St");
		assertTrue(con.getContactID().equals("123456"));
		assertTrue(con.getFirstName().equals("Joe"));
		assertTrue(con.getLastName().equals("Donald"));
		assertTrue(con.getPhoneNumber().equals("4879568759"));
		assertTrue(con.getAddress().equals("1234 Fake St"));
	}
	
	@Test
	public void testContactIDTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910" , "Joe", "Donald", "4879568759", "1234 Fake St");
		});
	}
	
	@Test
	public void testContactIDNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null , "Joe", "Donald", "4879568759", "1234 Fake St");
		});
	}
	
	@Test
	public void testContactFirstNameTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456" , "JoeJoeJoeJoe", "Donald", "4879568759", "1234 Fake St");
		});
	}
	@Test
	public void testContactFirstNameNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456" , null, "Donald", "4879568759", "1234 Fake St");
		});
	}
	
	@Test
	public void testContactLastNameTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456" , "Joe", "DonaldDonald", "4879568759", "1234 Fake St");
		});
	}
	
	@Test
	public void testContactLastNameNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456" , "Joe", null, "4879568759", "1234 Fake St");
		});
	}
	
	@Test
	public void testContactPhoneNumberTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910" , "Joe", "Donald", "48795687591", "1234 Fake St");
		});
	}
	
	@Test
	public void testContactPhoneNumberTooShort() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910" , "Joe", "Donald", "487956875", "1234 Fake St");
		});
	}
	
	@Test
	public void testContactPhoneNumberNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910" , "Joe", "Donald", null, "1234 Fake St");
		});
	}
	
	@Test
	public void testContactAddressTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910" , "Joe", "Donald", "4879568759", "1234 Fake St on a hill next to a school next to a fire department");
		});
	}
	
	@Test
	public void testContactAddressNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910" , "Joe", "Donald", "4879568759", null);
		});
	}
}
