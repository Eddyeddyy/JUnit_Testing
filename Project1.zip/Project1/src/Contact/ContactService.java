package Contact;

import java.util.ArrayList;

public class ContactService {

	private ArrayList<Contact> contacts;
	
	public ContactService() {
		contacts = new ArrayList<>();
	}
	
	public void addContact(Contact con) {
		for (Contact c : contacts) {
			if (c.getContactID().equals(con.getContactID())){
				break;
			}
		}
		contacts.add(con);
	}
	
	public void removeContact(String ID) {
		for (Contact c : contacts) {
			if (c.getContactID().equals(ID)) {
				contacts.remove(c);
			}
		}
	}
	
	public void updateContact(String ID, String fName, String lName, String phone, String address){
	
		for (Contact c : contacts) {
			if (c.getContactID().equals(ID)) {
				c.setFirstName(fName);
				c.setLastName(lName);
				c.setPhoneNumber(phone);
				c.setAddress(address);
			}
		}
		
	}
	
	public String getContact0() {
		return contacts.get(0).getContactID();
	}
}
