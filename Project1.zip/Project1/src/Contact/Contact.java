package Contact;


public class Contact {
	
	//class variables
	private String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	//constructor
	public Contact(String ID, String fName, String lName, String phone, String address) {	
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (fName == null || fName.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (lName == null || lName.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.contactID = ID;
		this.firstName = fName;
		this.lastName = lName;
		this.phoneNumber = phone;
		this.address = address;
	}
	
	//getters
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public String getAddress() {
		return address;
	}
	
	//setters
	public void setContactID(String ID) {
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.contactID = ID;
	}
	
	public void setFirstName(String fName) {
		if (fName == null || fName.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.firstName = fName;
	}
	
	public void setLastName(String lName) {
		if (lName == null || lName.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.lastName = lName;
	}
	
	public void setPhoneNumber(String phone) {
		if (phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.phoneNumber = phone;
	}
	
	public void setAddress(String address) {
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.address = address;
	}

	
}
