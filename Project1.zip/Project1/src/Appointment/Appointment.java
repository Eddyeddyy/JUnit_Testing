package Appointment;

import java.util.Date;

public class Appointment {

	private String appID;
	private Date appDate;
	private String appDescription;
	
	public Appointment(String ID, Date date, String desc){
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (desc == null || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.appID = ID;
		this.appDate = date;
		this.appDescription = desc;
	}
	
	public void setID(String ID) {
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.appID = ID;
	}
	
	public void setDate(Date date) {
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.appDate = date;
	}
	
	public void setDescription(String desc) {
		if (desc == null || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.appDescription = desc;
	}
	
	public String getID() {
		return appID;
	}
	
	public Date getDate() {
		return appDate;
	}
	
	public String getDescription() {
		return appDescription;
	}
}
