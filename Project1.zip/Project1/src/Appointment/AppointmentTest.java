package Appointment;

import static org.junit.Assert.assertTrue;
import java.util.Date;
import org.junit.Assert;
import org.junit.Test;

public class AppointmentTest {
	
	@Test
	public void testAppointment() {
		Appointment app = new Appointment("01221", new Date(), "Test appointment");
		assertTrue(app.getID().equals("01221"));
		Date date = app.getDate();
		assertTrue(date.equals(app.getDate()));
		assertTrue(app.getDescription().equals("Test appointment"));
	}
	
	@Test
	public void testAppointmentSetID() {
		Appointment app = new Appointment("01221", new Date(), "Test appointment");
		app.setID("01222");
		assertTrue(app.getID().equals("01222"));
	}
	

	@Test
	public void testAppointmentSetDescription() {
		Appointment app = new Appointment("01221", new Date(), "Test appointment");
		app.setDescription("Real Appointment");
		assertTrue(app.getDescription().equals("Real Appointment"));
	}
	
	
	@Test
	public void testAppointmentIDTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567891011", new Date(), "Test appointment");
		});
	}
	
	@Test
	public void testAppointmentIDNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, new Date(), "Test appointment");
		});
	}
	
	@Test
	public void testAppointmentDescriptionTooLong() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567891011", new Date(), "Test appointment, hfdsjhafhjdksla;fjkdls;afjkdls;afjdklsa;fjdklsa;fjdklsa;fjdkls;a");
		});
	}
	@Test
	public void testAppointmentDescriptionNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567891011", new Date(), null);
		});
	}
	
	@Test
	public void testAppointmentDateBefore() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567891011", new Date(2020, 10, 12), "Test appointment");
		});
	}
	
	@Test
	public void testAppointmentDateNull() {
		Assert.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567891011", null, "Test appointment");
		});
	}

}