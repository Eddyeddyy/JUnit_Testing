package Appointment;


import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import org.junit.Test;
public class AppointmentServiceTest {

	@Test
	public void testAppointmentServiceAdd() {
		AppointmentService appointment = new AppointmentService();
		AppointmentService appointment1 = new AppointmentService();
		Appointment app = new Appointment("01221", new Date(), "Test appointment");
		appointment.addAppointment(app);
		appointment1.addAppointment(app);
		assertTrue(appointment.getAppointment0().equals(appointment1.getAppointment0()));
	}
	
	@Test
	public void testAppointmentServiceDoubleAppointment() {
		AppointmentService appointment = new AppointmentService();
		AppointmentService appointment1 = new AppointmentService();
		Appointment app = new Appointment("01221", new Date(), "Test appointment");
		appointment.addAppointment(app);
		appointment1.addAppointment(app);
		appointment1.addAppointment(app);
		assertTrue(appointment.getAppointment0().equals(appointment1.getAppointment0()));
	}
	
	@Test
	public void testAppointmentServiceRemove() {
		AppointmentService appointment = new AppointmentService();
		AppointmentService appointment1 = new AppointmentService();
		Appointment app = new Appointment("01221", new Date(), "Test appointment");
		Appointment app1 = new Appointment("02112", new Date(), "Test appointment");
		appointment.addAppointment(app);
		appointment1.addAppointment(app);
		appointment1.addAppointment(app1);
		appointment1.removeAppointment(app);
		assertFalse(appointment.getAppointment0().equals(appointment1.getAppointment0()));
	}
}

