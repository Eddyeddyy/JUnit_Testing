package Appointment;

import java.util.ArrayList;

public class AppointmentService {

private ArrayList<Appointment> appointments;
	
	public AppointmentService() {
		appointments = new ArrayList<>();
	}
	
	public void addAppointment(Appointment app) {
		for (Appointment a : appointments) {
			if (a.getID().equals(app.getID())){
				break;
			}
		}
		appointments.add(app);
	}
	
	public void removeAppointment(Appointment app) {
		for (Appointment a : appointments) {
			if (a.getID().equals(app.getID())) {
				appointments.remove(a);
			}
		}
	}
	
	public String getAppointment0() {
		return appointments.get(0).getID();
	}
}

